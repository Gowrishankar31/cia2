
import './App.css';
import Color from './Components/color';

function App() {
  return (
    <div className="main">
      <h1>Choose To Change Color</h1>
      <Color />
    </div>
  );
}

export default App;
